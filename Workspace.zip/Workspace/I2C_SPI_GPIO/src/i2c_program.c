/*
 * data.c
 *
 *  Created on: Mar 9, 2025
 *      Author: Rhodz
 */
#include "uart.h"
#include "gpio.h"
#include "pic.h"
#include "sys_platform.h"
#include "utils.h"
#include <stdio.h>
#include "hal.h"
#include "i2c_master.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "i2c_program.h"

void i2c_program_XO3D(struct gpio_instance *gpio,struct i2cm_instance *i2c_master,uint8_t addr, const unsigned char *bitstream, const int bitstream_len,int CFG){
	printf("=======================================================\n");
	printf("Programming MachXO3D Via I2C with address: 0x%02x\n",addr);
	printf("=======================================================\n");

	i2c_device_id(i2c_master,addr);//Device ID check
	i2c_isc_enable_sram(i2c_master,addr);//ISC Enable SRAM
	i2c_isc_erase_sram(i2c_master,addr);//ISC Erase SRAM
	i2c_sr_read(i2c_master,addr);//Status Register Read
	i2c_isc_enable_flash_XO2_XO3(i2c_master,addr);//ISC Enable Flash
	i2c_isc_erase_flash_XO3D(gpio,i2c_master,addr,CFG);// ISC Erase Flash
	i2c_sr_read(i2c_master,addr);// Status Register Read
	i2c_lsc_init_address_XO3D(i2c_master,addr,CFG);// Init Address CFGX
	i2c_flash_program(gpio ,i2c_master,addr,bitstream,bitstream_len);//Flash Program
	i2c_lsc_init_address_XO3D(i2c_master,addr,CFG);//Init Address CFGX
	i2c_flash_verify(gpio,i2c_master,addr,bitstream,bitstream_len);//Flash Verify
	i2c_lsc_init_address_XO3D(i2c_master,addr,CFG);//Init Address CFGX
	i2c_program_done(i2c_master,addr);// Program Done bit
	i2c_sr_read(i2c_master,addr);// Status Register Read
	i2c_isc_disable(i2c_master,addr);//Device Exits Programming mode*/

}

void i2c_program_XO2_XO3(struct gpio_instance *gpio,struct i2cm_instance *i2c_master,uint8_t addr, const unsigned char *bitstream,const int bitstream_len){

	printf("=======================================================\n");
	printf("Programming MachXO2/XO3 Via I2C with address: 0x%02x\n",addr);
	printf("=======================================================\n");
	i2c_device_id(i2c_master,addr);//Device ID check
	i2c_isc_enable_sram(i2c_master,addr);//ISC Enable SRAM
	i2c_isc_erase_sram(i2c_master,addr);//ISC Erase SRAM
	i2c_sr_read(i2c_master,addr);//Status Register Read
	i2c_isc_enable_flash_XO2_XO3(i2c_master,addr);//ISC Enable Flash
	i2c_sr_read(i2c_master,addr);//Status Register Read
	i2c_lsc_init_address_XO2_XO3(i2c_master,addr);
	i2c_flash_program(gpio,i2c_master,addr,bitstream,bitstream_len);//Flash Program
	i2c_lsc_init_address_XO2_XO3(i2c_master,addr);
	i2c_flash_verify(gpio,i2c_master,addr,bitstream,bitstream_len);//Flash Verify
	i2c_program_done(i2c_master,addr);// Program Done bit
	i2c_sr_read(i2c_master,addr);// Status Register Read
	i2c_isc_disable(i2c_master,addr);//Device Exits Programming mode*/

}


void i2c_isc_disable(struct i2cm_instance *i2c_master,uint8_t addr){

	uint8_t isc_disable[4]={0x26,0x00,0x00,0x00};
	i2c_master_write(i2c_master, addr, 4, isc_disable);
	printf("Device Exits Programming Mode!\n");
}
void i2c_program_done(struct i2cm_instance *i2c_master,uint8_t addr){
	uint8_t program_done[4]={0x5E,0x00,0x00,0x00};
	i2c_master_write(i2c_master, addr, 4,program_done);
	delayMS(1);
	printf("Programmed CFG Internal Done bit!\n");

}
void i2c_flash_verify(struct gpio_instance *gpio,struct i2cm_instance *i2c_master,uint8_t addr,const unsigned char *bitstream,const int bit_len){

	int num_chunks= ((bit_len + 16 - 1) / 16);
	uint8_t lsc_read_incr[4]={0x73,0x00,0x00,0x00};
	uint8_t read_buffer[16];

    printf("Verifying internal flash..\n");
   for(int k=0;k<num_chunks;k++){
       i2c_master_repeated_start(i2c_master,addr,4,lsc_read_incr,16,read_buffer);
   if (memcmp( read_buffer, &bitstream[k*16], 16) == 0) {

   } else {
       printf("Verify Fail\n");
       gpio_output_write(gpio,0, 1);
       exit(0);
   }
	if (k%200==0){
		gpio_output_write(gpio,0, 1);
	}

	else if (k%200==100) {
		gpio_output_write(gpio,0, 0);

	}

   delayMS(2);
   }
   printf("Verify Successful!\n");
   gpio_output_write(gpio,0, 0);

}


void i2c_flash_program(struct gpio_instance *gpio, struct i2cm_instance *i2c_master,uint8_t addr,const unsigned char *bitstream,const int bit_len){
	uint8_t lsc_prog_incr[4]={0x70,0x00,0x00,0x00};
	uint8_t prog_buffer[20];
	int num_chunks= ((bit_len + 16 - 1) / 16);
	int step = bit_len/7;
	int level=0;
	printf("Programming internal flash..\n");
	for(int k=0;k<num_chunks;k++){
		memcpy(prog_buffer, lsc_prog_incr, 4);
		memcpy(prog_buffer+4, &bitstream[k*16], 16);
		i2c_master_write(i2c_master, addr, 20, prog_buffer);
		delayMS(2);
		if (k%200==0){
			gpio_output_write(gpio,0, 1);
		}

		else if (k%200==100) {
			gpio_output_write(gpio,0, 0);

		}
	  }
	gpio_output_write(gpio,0, 0);
	printf("Finished Programming internal flash!\n");



}
void i2c_lsc_init_address_XO3D(struct i2cm_instance *i2c_master,uint8_t addr,int CFG){
	uint8_t lsc_init_address[4]={0x46,0x00,0x01,0x00};
	 if (CFG==0){
		 lsc_init_address[2]=0x01;
		 printf("Init Address at CFG0\n");
	 }

	 else if (CFG==1){
		 lsc_init_address[2]=0x02;
		 printf("Init Address at CFG1\n");
	 }

	 else if (CFG==3){
		 lsc_init_address[2] =0x00;
		 lsc_init_address[1] =0x04;
		 printf("Init Address at feature row\n");

	 }

	 else{

		 printf("Not a Valid sector\n");
	 }
	i2c_master_write(i2c_master, addr, 4, lsc_init_address);
	delayMS(1);
}


void i2c_lsc_init_address_XO2_XO3(struct i2cm_instance *i2c_master,uint8_t addr){
	uint8_t lsc_init_address[4]={0x46,0x04,0x00,0x00};

	printf("Init Address at Internal Flash!\n");



	i2c_master_write(i2c_master, addr, 4, lsc_init_address);
	delayMS(1);
}




void i2c_isc_erase_flash_XO3D(struct gpio_instance *gpio,struct i2cm_instance *i2c_master,uint8_t addr, int CFG){
	 printf("Erasing Internal Flash.....\n");
	 uint8_t isc_erase_flash[4]={0x0E,0x00,0x01,0x00};
	 if (CFG==0){
		 isc_erase_flash[2]=0x01;
	 }

	 else{
		 isc_erase_flash[2]=0x02;

	 }

		i2c_master_write(i2c_master, addr, 4, isc_erase_flash);

		//delayMS(8000);
		int total_ms=8000;
		int elapsed=0;
		int led_state=0;
	    while (elapsed < total_ms) {
	        gpio_output_write(gpio, 0, led_state);         // Set LED
	        led_state = !led_state;                          // Toggle LED
	        delayMS(500);                      // Wait
	        elapsed +=500;                    // Accumulate time
	    }
	 printf("Internal Flash Erased!\n");



}

void i2c_isc_erase_flash_XO2_XO3(struct gpio_instance *gpio,struct i2cm_instance *i2c_master,uint8_t addr ){
	 printf("Erasing Internal Flash.....\n");
	 uint8_t isc_erase_flash[4]={0x0E,0x04,0x00,0x00};


		i2c_master_write(i2c_master, addr, 4, isc_erase_flash);

		//delayMS(8000);
		int total_ms=8000;
		int elapsed=0;
		int led_state=0;
	    while (elapsed < total_ms) {
	        gpio_output_write(gpio, 0, led_state);         // Set LED
	        led_state = !led_state;                          // Toggle LED
	        delayMS(500);                      // Wait
	        elapsed +=500;                    // Accumulate time
	    }
	 printf("Internal Flash Erased!\n");



}

void i2c_isc_enable_flash_XO2_XO3(struct i2cm_instance *i2c_master,uint8_t addr){
	uint8_t isc_enable_flash[4]={0xC6,0x08,0x00};
	i2c_master_write(i2c_master, addr, 3, isc_enable_flash);
	delayMS(1);
	printf("Device Enters Config Mode: Flash\n");

}
void i2c_sr_read(struct i2cm_instance *i2c_master,uint8_t addr){
	uint8_t status_reg[4]={0x3C,0x00,0x00,0x00};
	uint8_t read[4];
	i2c_master_repeated_start(i2c_master,addr,4,status_reg,4,read);
	printf("Status Register Read\n");
	for(int i=0;i<4;i++){
			printf("0x%02x\n",read[i]);

	}

}
void i2c_isc_erase_sram(struct i2cm_instance *i2c_master,uint8_t addr){
	uint8_t isc_erase_sram[4]={0x0E,0x01,0x00,0x00};
	printf("Erasing internal SRAM\n");
	i2c_master_write(i2c_master, addr, 4, isc_erase_sram);
	delayMS(5);

}

void i2c_isc_enable_sram(struct i2cm_instance *i2c_master,uint8_t addr){
	uint8_t isc_enable_sram[4]={0xC6,0x00,0x00,0x00};
	i2c_master_write(i2c_master, addr, 4, isc_enable_sram);
	delayMS(1);
	printf("Device Enters Config Mode: SRAM\n");


}

void  i2c_device_id(struct i2cm_instance *i2c_master,uint8_t addr){

	uint8_t device_id[4]={0xE0,0x00,0x00,00};
	uint8_t read[4];
	i2c_master_repeated_start(i2c_master,addr,4,device_id,4,read);
	printf("Device ID Read\n");
	for(int i=0;i<4;i++){
			printf("0x%02x\n",read[i]);

	}


}


