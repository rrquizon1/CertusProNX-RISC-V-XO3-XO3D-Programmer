/*
 * data.h
 *
 *  Created on: Mar 9, 2025
 *      Author: Rhodz
 */

#ifndef INC_DATA_H_
#define INC_DATA_H_
extern const int g_int_XO3;
extern const unsigned char g_pucDataArray_XO3[];
extern const int g_int_XO3D;
extern const unsigned char g_pucDataArray_XO3D[];


#endif /* INC_DATA_H_ */
